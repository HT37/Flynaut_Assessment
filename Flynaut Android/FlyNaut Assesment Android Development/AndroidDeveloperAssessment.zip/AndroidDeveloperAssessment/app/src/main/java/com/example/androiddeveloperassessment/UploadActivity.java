package com.example.androiddeveloperassessment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class UploadActivity extends AppCompatActivity {
    TextView imageUpload, videoUpload;
    TextView textName, textEmail, textPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);

        imageUpload = findViewById(R.id.btn_imageUpload);
        videoUpload = findViewById(R.id.btn_videoUpload);

        imageUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadActivity.this, imageActivity.class);
                startActivity(intent);
            }
        });

        videoUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UploadActivity.this, videoActivity.class);
                startActivity(intent);
            }
        });
    }

}

