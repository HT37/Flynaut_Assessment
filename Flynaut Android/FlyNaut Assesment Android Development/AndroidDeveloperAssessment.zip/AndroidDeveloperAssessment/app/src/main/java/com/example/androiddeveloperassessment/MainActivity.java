package com.example.androiddeveloperassessment;


import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private EditText fullNameEditText;
    private EditText emailEditText;
    private EditText phoneNumberEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fullNameEditText = findViewById(R.id.name);
        emailEditText = findViewById(R.id.email);
        phoneNumberEditText = findViewById(R.id.phone);
        submitButton = findViewById(R.id.btn_submit);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = fullNameEditText.getText().toString().trim();
                String email = emailEditText.getText().toString().trim();
                String phoneNumber = phoneNumberEditText.getText().toString().trim();

                boolean isValid = true;

                // Check if fields are empty
                if (TextUtils.isEmpty(name)) {
                    isValid = false;
                    fullNameEditText.setError("Please enter your name");
                }

                if (TextUtils.isEmpty(email)) {
                    isValid = false;
                    emailEditText.setError("Please enter your email");
                }

                if (TextUtils.isEmpty(phoneNumber)) {
                    isValid = false;
                    phoneNumberEditText.setError("Please enter your phone number");
                }

                // Check email format
                if (!TextUtils.isEmpty(email) && !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    isValid = false;
                    emailEditText.setError("Invalid email format");
                }

                // Check mobile number length
                if (!TextUtils.isEmpty(phoneNumber) && phoneNumber.length() != 10) {
                    isValid = false;
                    phoneNumberEditText.setError("Mobile number should be 10 digits");
                }

                prepareJson(name,email,phoneNumber);

                if (isValid) {
                    // Clear the errors
                    fullNameEditText.setError(null);
                    emailEditText.setError(null);
                    phoneNumberEditText.setError(null);


                    // Continue with submit logic
                    Intent intent = new Intent(MainActivity.this, UploadActivity.class);
                    startActivity(intent);


                }
            }
//  Converting data into json format this data will be available in Console 
            private void prepareJson(String name, String email, String phoneNumber) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("Name", name);
                    jsonObject.put("Email", email);
                    jsonObject.put("Phone Number", phoneNumber);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                String json = jsonObject.toString();
                System.out.println("Data in Json Format which we can manipulate according to our use " + json);

            }
        });


    }
    protected void onResume() {
        super.onResume();

        // Clear the EditText fields
        fullNameEditText.setText("");
        emailEditText.setText("");
        phoneNumberEditText.setText("");
    }
}


